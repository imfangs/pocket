import { KEYWORDS, T } from './tokens.js';
import { isLineEnd, isSpace, isWord } from '../../util/chars.js';

export interface Tokens {
  types: number[];
  texts: string[];
  starts: number[];
}

const enum S {
  INITIAL,
  string,
  style,
  acc_title,
  acc_descr,
  acc_descr_multiline,
}

const RE_ACC_TITLE = /accTitle\s*:\s*/iy;
const RE_ACC_DESCR = /accDescr\s*:\s*/iy;
const RE_ACC_DESCR_ML = /accDescr\s*\{\s*/iy;
const RE_DIRECTION = /direction\s+(?:(TB)|(BT)|(RL)|LR)/gi;
const RE_LINE_END = /[\n\r\u2028\u2029]/g;
const LONGEST_KEYWORD = 22;

// Characters that end an unquoted string: `:,{<>-=` and line breaks.
const STOP = new Uint8Array(128);
for (const ch of ':,\r\n{<>-=') STOP[ch.charCodeAt(0)] = 1;

// Produces the token stream of Mermaid's requirement lexer. Its rules are tried in order and
// the first match wins, so a line that holds a direction statement anywhere is one token.
export function tokenize(src: string): Tokens {
  const n = src.length;
  const types: number[] = [];
  const texts: string[] = [];
  const starts: number[] = [];
  const stack: number[] = [];
  let state: number = S.INITIAL;
  let p = 0;

  // Where each kind of direction statement starts and where its keyword ends, found in one pass.
  const dirStarts: number[][] = [[], [], [], []];
  const dirEnds: number[][] = [[], [], [], []];
  const dirSeen = [0, 0, 0, 0];
  let anyDir = false;
  let lineEnd = -1;
  RE_DIRECTION.lastIndex = 0;
  for (let m = RE_DIRECTION.exec(src); m !== null; m = RE_DIRECTION.exec(src)) {
    const kind = m[1] !== undefined ? 0 : m[2] !== undefined ? 1 : m[3] !== undefined ? 2 : 3;
    dirStarts[kind].push(m.index);
    dirEnds[kind].push(RE_DIRECTION.lastIndex);
    anyDir = true;
  }

  const emit = (type: number, s: number, e: number): void => {
    types.push(type);
    texts.push(src.slice(s, e));
    starts.push(s);
    p = e;
  };
  const push = (s: number): void => {
    stack.push(state);
    state = s;
  };
  const pop = (): void => {
    if (stack.length > 0) state = stack.pop()!;
  };
  const at = (re: RegExp, q: number): number => {
    re.lastIndex = q;
    return re.test(src) ? re.lastIndex : -1;
  };
  const lineBreak = (q: number): number => {
    const e = src.indexOf('\n', q);
    return e === -1 ? n : e;
  };

  // `.*direction\s+XX[^\n]*`: the last such statement that starts on this line decides the token.
  const direction = (): boolean => {
    if (lineEnd < p) {
      RE_LINE_END.lastIndex = p;
      lineEnd = RE_LINE_END.test(src) ? RE_LINE_END.lastIndex - 1 : n;
      for (let k = 0; k < 4; k++) {
        const list = dirStarts[k];
        let j = dirSeen[k];
        while (j < list.length && list[j] <= lineEnd) j++;
        dirSeen[k] = j;
      }
    }
    for (let k = 0; k < 4; k++) {
      const j = dirSeen[k] - 1;
      if (j >= 0 && dirStarts[k][j] >= p) {
        emit(T.direction_tb + k, p, lineBreak(dirEnds[k][j]));
        return true;
      }
    }
    return false;
  };

  const initial = (c: number): boolean => {
    const lower = c | 32;
    if (lower === 116 && src.slice(p + 1, p + 5).toLowerCase() === 'itle' && isSpace(src.charCodeAt(p + 5))) {
      let q = p + 6;
      while (q < n) {
        const d = src.charCodeAt(q);
        if (d === 35 || d === 10 || d === 59) break;
        q++;
      }
      if (q > p + 6) {
        emit(T.title, p, q);
        return true;
      }
    }
    if (lower === 97 && (src.charCodeAt(p + 1) | 32) === 99 && (src.charCodeAt(p + 2) | 32) === 99) {
      let e: number;
      if ((e = at(RE_ACC_TITLE, p)) >= 0) {
        push(S.acc_title);
        emit(T.acc_title, p, e);
        return true;
      }
      if ((e = at(RE_ACC_DESCR, p)) >= 0) {
        push(S.acc_descr);
        emit(T.acc_descr, p, e);
        return true;
      }
      if ((e = at(RE_ACC_DESCR_ML, p)) >= 0) {
        push(S.acc_descr_multiline);
        p = e;
        return true;
      }
    }
    if (anyDir && !isLineEnd(c) && direction()) return true;

    if (c === 10 || (c === 13 && src.charCodeAt(p + 1) === 10)) {
      let q = p;
      while (q < n) {
        const d = src.charCodeAt(q);
        if (d === 10) q++;
        else if (d === 13 && src.charCodeAt(q + 1) === 10) q += 2;
        else break;
      }
      emit(T.NEWLINE, p, q);
      return true;
    }
    if (isSpace(c)) {
      p++;
      while (p < n && isSpace(src.charCodeAt(p))) p++;
      return true;
    }
    if (c === 35 || c === 37) {
      p = lineBreak(p);
      return true;
    }

    if (isWord(c)) {
      let q = p + 1;
      while (q < n && isWord(src.charCodeAt(q))) q++;
      if (q - p <= LONGEST_KEYWORD) {
        const keyword = KEYWORDS.get(src.slice(p, q).toLowerCase());
        if (keyword !== undefined) {
          if (keyword === T.STYLE || keyword === T.CLASSDEF || keyword === T.CLASS) push(S.style);
          emit(keyword, p, q);
          return true;
        }
      }
      while (q < n) {
        const d = src.charCodeAt(q);
        if (d < 128 && STOP[d] === 1) break;
        q++;
      }
      types.push(T.unqString);
      texts.push(src.slice(p, q).trim());
      starts.push(p);
      p = q;
      return true;
    }

    switch (c) {
      case 123:
        emit(T.STRUCT_START, p, p + 1);
        return true;
      case 125:
        emit(T.STRUCT_STOP, p, p + 1);
        return true;
      case 58:
        if (src.charCodeAt(p + 1) === 58 && src.charCodeAt(p + 2) === 58) emit(T.STYLE_SEPARATOR, p, p + 3);
        else emit(T.COLONSEP, p, p + 1);
        return true;
      case 60:
        if (src.charCodeAt(p + 1) !== 45) return false;
        emit(T.END_ARROW_L, p, p + 2);
        return true;
      case 45:
        if (src.charCodeAt(p + 1) === 62) emit(T.END_ARROW_R, p, p + 2);
        else emit(T.LINE, p, p + 1);
        return true;
      case 34:
        push(S.string);
        p++;
        return true;
      case 44:
        emit(T.COMMA, p, p + 1);
        return true;
    }
    return false;
  };

  const style = (c: number): boolean => {
    if (isWord(c)) {
      let q = p + 1;
      while (q < n && isWord(src.charCodeAt(q))) q++;
      emit(T.ALPHA, p, q);
      return true;
    }
    switch (c) {
      case 58:
        emit(T.COLON, p, p + 1);
        return true;
      case 59:
        emit(T.SEMICOLON, p, p + 1);
        return true;
      case 37:
        emit(T.PERCENT, p, p + 1);
        return true;
      case 45:
        emit(T.MINUS, p, p + 1);
        return true;
      case 35:
        emit(T.BRKT, p, p + 1);
        return true;
      case 32:
        p++;
        return true;
      case 34:
        push(S.string);
        p++;
        return true;
      case 10:
        pop();
        p++;
        return true;
      case 44:
        emit(T.COMMA, p, p + 1);
        return true;
    }
    return false;
  };

  while (p < n) {
    const c = src.charCodeAt(p);
    let ok = true;
    switch (state) {
      case S.INITIAL:
        ok = initial(c);
        break;
      case S.style:
        ok = style(c);
        break;
      case S.string:
        if (c === 34) {
          pop();
          p++;
        } else {
          const e = src.indexOf('"', p);
          emit(T.qString, p, e === -1 ? n : e);
        }
        break;
      case S.acc_title:
        pop();
        emit(T.acc_title_value, p, lineBreak(p));
        break;
      case S.acc_descr:
        pop();
        emit(T.acc_descr_value, p, lineBreak(p));
        break;
      case S.acc_descr_multiline:
        if (c === 125) {
          pop();
          p++;
        } else {
          const e = src.indexOf('}', p);
          emit(T.acc_descr_multiline_value, p, e === -1 ? n : e);
        }
        break;
    }
    if (!ok) {
      types.push(T.ERROR);
      texts.push('');
      starts.push(p);
      return { types, texts, starts };
    }
  }

  // At the end of input Jison still tries the rules that can match nothing, once.
  const last =
    state === S.INITIAL
      ? T.EOF
      : state === S.string
        ? T.qString
        : state === S.acc_title
          ? T.acc_title_value
          : state === S.acc_descr
            ? T.acc_descr_value
            : state === S.acc_descr_multiline
              ? T.acc_descr_multiline_value
              : -1;
  if (last !== -1) emit(last, n, n);
  emit(T.END, n, n);
  return { types, texts, starts };
}
