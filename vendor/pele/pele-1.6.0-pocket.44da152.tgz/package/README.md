# Pele for Pocket

Local build 1.6.0-pocket.44da152, from https://github.com/obsidianmd/pele/tree/44da152bbb79b91f03e68016f42499bb25bf6e82.
Includes the upstream CJK line-wrapping fix after 1.6.0. No upstream runtime source was modified.
Only core, flowchart, sequence and state runtime entry points are included. Root import is core;
register the selected diagram types explicitly. No lazy/all-diagrams entry is provided.
Build recipe, source checksums and provenance are maintained in Pocket vendor/pele/.
MIT license and original upstream README are included. This is not an official npm release.
